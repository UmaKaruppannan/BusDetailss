package com.capgemini.bean;

public class BookingBean 
{
	private int bookingId ;
	private int noOfSeat ;
	private int busId ;
	private String custId ;
	
	@Override
	public String toString() 
	{
		return "BookingBean [bookingId=" + bookingId + ", noOfSeat=" + noOfSeat
				+ ", busId=" + busId + ", custId=" + custId + "]";
	}

	public BookingBean(int bookingId, int noOfSeat, int busId, String custId) 
	{
		super();
		this.bookingId = bookingId;
		this.noOfSeat = noOfSeat;
		this.busId = busId;
		this.custId = custId;
	}
	
	
	public BookingBean() 
	{
		
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getNoOfSeat() {
		return noOfSeat;
	}

	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookingId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingBean other = (BookingBean) obj;
		if (bookingId != other.bookingId)
			return false;
		return true;
	}
	
	
}
