package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public interface IBusDAO 
{
	public ArrayList<BusBean> retrieveBusDetails() ;
	public int bookTicket(BookingBean bookingBean ) throws BookingException ;
}
